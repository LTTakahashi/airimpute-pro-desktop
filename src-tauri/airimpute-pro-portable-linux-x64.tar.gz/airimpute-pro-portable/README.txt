AirImpute Pro - Portable Linux Bundle
=====================================

This is a portable bundle that includes compatible libraries
to work around the libsoup2/libsoup3 conflict on modern Linux systems.

To run:
  ./airimpute-pro.sh

This bundle includes:
- AirImpute Pro binary
- libsoup 2.4 (compatible version)
- webkit2gtk 4.0 libraries

Note: This is a temporary solution. Future versions will use
Tauri v2 which properly handles these library conflicts.
